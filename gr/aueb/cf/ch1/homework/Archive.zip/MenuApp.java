package gr.aueb.cf.ch1;

public class MenuApp {
    public static void main(String[] args) {
        System.out.print("1. Εισαγωγή\n2. Διαγραφή\n3. Αναζήτηση\n4. Ενημέρωση\n5. ®Έξοδος\nΔώστε αριθμό επιλογής:");
    }
}
