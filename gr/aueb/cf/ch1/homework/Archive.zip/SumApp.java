package gr.aueb.cf.ch1;

public class SumApp {
    public static void main(String[] args) {
        int num1;
        int num2;
        int sum;

        num1 = 19;
        num2 = 30;
        sum = num1 + num2;

        System.out.printf("Το αποτέλεσμα της πρόσθεσης είναι ίσο με %d", sum);
    }
}
