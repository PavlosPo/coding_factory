/**
 * This package is the answer for the second homework provided by the Coding Factory.
 * It includes the following classes:
 * <br>
 * {@link gr.aueb.cf.ch14_homework.exerciseTwo.User}
 *
 * @since 0.0.1
 * @version 0.1
 * @author pavlospoulos
 */
package gr.aueb.cf.ch14_homework.exerciseTwo;